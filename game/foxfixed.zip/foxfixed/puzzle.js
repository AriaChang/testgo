$( function() {
							
	var count = 0;
	var cong = document.createElement("img");
	cong.src = "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwjb85yXoPzaAhVL7GMKHSD8Cj4QjRx6BAgBEAU&url=https%3A%2F%2Fwww.freeiconspng.com%2Fimg%2F22070&psig=AOvVaw11w7Ppi8jFVavyYZx3ZEyk&ust=1526079685603920";
	
  
	$("#01").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
					  });
	$("#02").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#03").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#04").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#05").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#06").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#07").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#08").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#09").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#10").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#11").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	$("#12").sortable({count++;
	if(count==12){
		$('.cong').prepend(cong);
		}
	});
	
	});
